<?php
// تحديد اسم ملف JSON
$file = 'comments.json';

// الحصول على البيانات المدخلة من طلب POST
$data = json_decode(file_get_contents("php://input"));

// تحقق من وجود تعليق واسم المستخدم والتقييم
if (isset($data->comment) && isset($data->username) && isset($data->rating)) {
    // استرجاع التعليقات السابقة، إذا كانت موجودة
    if (file_exists($file)) {
        $comments = json_decode(file_get_contents($file), true);
    } else {
        $comments = [];
    }

    // إضافة التعليق الجديد مع اسم المستخدم والتقييم
    $newComment = [
        'username' => $data->username,
        'comment' => $data->comment,
        'rating' => $data->rating,
    ];
    $comments[] = $newComment;

    // حفظ التعليقات في ملف JSON
    if (file_put_contents($file, json_encode($comments, JSON_PRETTY_PRINT))) {
        echo json_encode(['message' => 'تم إرسال التعليق بنجاح!']);
    } else {
        echo json_encode(['message' => 'فشل في حفظ التعليق.']);
    }
} else {
    // إرسال رد بالفشل
    echo json_encode(['message' => 'فشل في إرسال التعليق.']);
}
?>
